<?php

// Uses the template of Back-END
require_once JPATH_COMPONENT_ADMINISTRATOR . DS . 'views' . DS . 'members' . DS . 'tmpl' . DS . 'default_group.php';
