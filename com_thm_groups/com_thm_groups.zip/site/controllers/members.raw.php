<?php

require_once JPATH_COMPONENT_ADMINISTRATOR . DS . 'controllers' . DS . 'members.raw.php';