<?php die;?>
THM Groups 3.5.2
================================================================================
+ New database scheme
+ New Back-End views
+ New Front-End view for quickpages
+ Validation of user input added
# Multiple bug fixes

THM Groups 3.4.11
================================================================================
# [MEDIUM] Profile view, css was changed
# [MEDIUM] Install script updated
# [MEDIUM] Membermanager - filter logik fixed
# [MEDIUM] Quickpages can be activated after user activating
# [MEDIUM] Back button in profile view fixed

THM Groups 3.4.10
================================================================================
# [MEDIUM] Bug fixes
# [MEDIUM] Members plugin was changed, new functions were added

THM Groups 3.4.9
================================================================================
# [MEDIUM] Update script was changed
+ Changelog was added

THM Groups 3.4.8
================================================================================
- Single article view is no more in menu view accessible
~ Username is no more a part of structure manager

THM Groups 3.4.7
================================================================================
+ New picture for quickpages linklist module was added
# Language constants fix
# [HIGH] Security update
# [MEDIUM] Structure manager - order fix
# [LOW] Edit profile - attributes with blank characters fixed
+ Quickpages - new title was added, name linked to profile page
