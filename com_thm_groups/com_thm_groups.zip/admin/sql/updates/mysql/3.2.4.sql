ALTER TABLE  `#__thm_groups_picture_extra`
ADD COLUMN `path` varchar(255) NOT NULL DEFAULT 'components/com_thm_groups/img/portraits';
