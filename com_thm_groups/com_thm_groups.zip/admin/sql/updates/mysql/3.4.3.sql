CREATE TABLE IF NOT EXISTS `#__thm_quickpages_featured` (
  `conid` int NOT NULL,
  PRIMARY KEY (`conid`)
) ENGINE = INNODB DEFAULT CHARSET=utf8;